## CONVERTS MS DATA TO SHAPEIT OUTPUT FORMAT, WHICH CAN BE READ IN BY RELATE

## usage:  perl MStoShapeItOutputTUTORIAL.pl

###################################
## INPUT:

                       ## INFILES:
$simname="sim1";
$msFILE="${simname}.ms";
$N0=10000;         ## effective diploid pop size at present-day

                       ## OUTFILES:
$shapeitHAP="${simname}.haps";
$shapeitRECOM="${simname}.map";
$shapeitSAMPLE="${simname}.sample";
$relatePOP="${simname}.poplabels";

#####################################
## PROGRAM:

$Mb=1000000;

                    ## (I) FIND RECOM RATE/NUM-INDS AND POP INFORMATION:
open(IN,"$msFILE");
$line=<IN>;
@linearray=split(/\s+/,$line);
$nhaps=$linearray[1];
$nsims=$linearray[2];
shift(@linearray);
shift(@linearray);
shift(@linearray);
$linelength=@linearray;
for ($i=0; $i < $linelength; $i+=1)
{
    @lineval=split(/-/,$linearray[$i]);
    if ($lineval[1] eq 'r')
    {
	last;
    }
}
$recomrate=$linearray[($i+1)];
$seqlength=$linearray[($i+2)];
$cMperbp=100*$recomrate/(4*$N0*$seqlength);
$foundPOPS=0;
for ($i=0; $i < $linelength; $i+=1)
{
    @lineval=split(/-/,$linearray[$i]);
    if ($lineval[1] eq 'I')
    {
	$foundPOPS=1;
	last;
    }
}
if ($foundPOPS==1)
{
    $numpops=$linearray[($i+1)];
    @popnumvec=();
    for ($j=1; $j <= $numpops; $j+=1)
    {
	push(@popnumvec,$linearray[($i+$j+1)]/2);
    }
}

$line=<IN>;
for ($n=0; $n < $nsims; $n+=1)
{
                    ## (II) FIND REPEAT SITES:
    $line=<IN>;
    $line=<IN>;
    $line=<IN>;
    @linearray=split(/\s+/,$line);
    $nsites=$linearray[1];
    $line=<IN>;
    @posvec=split(/\s+/,$line);
    shift(@posvec);
    @posvecfinal=();
    @tokeep=();
    #$posval=printf("%.0f",$posvec[0]*$seqlength);
    $posval=int($posvec[0]*$seqlength);
    push(@posvecfinal,$posval);
    $prevpos=$posval;
    push(@tokeep,1);
    $nsitesFINAL=1;
    for ($j=1; $j < $nsites; $j+=1)
    {
	#print "$j $nsites\n"; 
	#$posval=sprintf("%.0f",$posvec[$j]*$seqlength);
	$posval=int($posvec[$j]*$seqlength);
	$newpos=$posval;
	if ($newpos <= $prevpos)
	{
	    $newpos=$prevpos+1;
	}
	push(@posvecfinal,$newpos);
	push(@tokeep,1);
	$prevpos=$newpos;
	$nsitesFINAL=$nsitesFINAL+1;
    }
 
                    ## (III) CONVERT HAPLOTYPE FILES:
    @genomat=();
    for ($h=0; $h < $nhaps; $h+=1)
    {
	$line=<IN>;
	@linearray=split(//,$line);
	for ($j=0; $j < $nsites; $j+=1)
	{
	    if ($tokeep[$j]==1)
	    {
		$genomat[$h][$j]=$linearray[$j];
	    }
	}
    }
    $g=$n+1;
    $outfile="${shapeitHAP}";
    open(OUT,">$outfile");
    for ($j=0; $j < $nsitesFINAL; $j+=1)
    {
	$s=$j+1;
	print OUT "$g SNP${s} $posvecfinal[$j] A G";
	for ($h=0; $h < $nhaps; $h+=1)
	{
	    print OUT " $genomat[$h][$j]";
	}
	print OUT "\n";
    }
    close(OUT);
    @genomat=();

                    ## (IV) CONVERT RECOM FILES:
    $outfile="${shapeitRECOM}";
    open(OUT,">$outfile");
    print OUT "pos COMBINED_rate Genetic_Map\n";
    $recomval=$cMperbp*$Mb;
    $totalcM=0;
    for ($j=0; $j < $nsitesFINAL; $j+=1)
    {
	$totalcMtoprint=sprintf("%.6f",$totalcM);
	print OUT "$posvecfinal[$j] $recomval $totalcMtoprint\n";
	if ($j < ($nsitesFINAL-1))
	{
	    $totalcM=$totalcM+$cMperbp*($posvecfinal[($j+1)]-$posvecfinal[$j]);
	}
    }
    close(OUT);
}
close(IN);

                    ## (V) CONVERT ID FILE AND MAKE POP-LABELS FILE:
open(OUT,">$shapeitSAMPLE");
open(OUT2,">$relatePOP");
print OUT "ID_1 ID_2 missing\n";
print OUT "0 0 0\n";
print OUT2 "sample population group sex\n";
$nind=$nhaps/2;
@indvec=();
for ($h=0; $h < $nind; $h+=1)
{
    $i=$h+1;
    print OUT "IND${i} IND${i} 0\n";
    if ($foundPOPS==0)
    {
	print OUT2 "IND${i} Pop1 1 1\n";
    }
    push(@indvec,"$IND${i}");
}
close(OUT);
if ($foundPOPS==1)
{
    $count=0;
    for ($j=1; $j <= $numpops; $j+=1)
    {
	for ($h=0; $h < $popnumvec[($j-1)]; $h+=1)
	{
	    print OUT2 "$indvec[$count] Pop${j} $j 1\n";
	    $count=$count+1;
	}
    }
}
close(OUT2);
