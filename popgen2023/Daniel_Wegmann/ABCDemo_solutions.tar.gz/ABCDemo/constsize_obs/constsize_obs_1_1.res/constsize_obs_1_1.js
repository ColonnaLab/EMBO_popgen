
USETEXTLINKS = 1
STARTALLOPEN = 0
WRAPTEXT = 1
PRESERVESTATE = 0
HIGHLIGHT = 1
ICONPATH = 'file:////home/wegmann/ABC_test/ABCDemo/'    //change if the gif's folder is a subfolder, for example: 'images/'

foldersTree = gFld("<i>ARLEQUIN RESULTS (constsize_obs_1_1.arp)</i>", "")
insDoc(foldersTree, gLnk("R", "Arlequin log file", "Arlequin_log.txt"))
	aux1 = insFld(foldersTree, gFld("Run of 24/03/22 at 13:16:22", "constsize_obs_1_1.xml#24_03_22at13_16_22"))
	insDoc(aux1, gLnk("R", "Settings", "constsize_obs_1_1.xml#24_03_22at13_16_22_run_information"))
		aux2 = insFld(aux1, gFld("Shared haplotypes", "constsize_obs_1_1.xml#24_03_22at13_16_22_shared%20haplotypes"))
		insDoc(aux2, gLnk("R", "Sample 1", "constsize_obs_1_1.xml#24_03_22at13_16_22_gr_shared0"))
		aux2 = insFld(aux1, gFld("Samples", ""))
		insDoc(aux2, gLnk("R", "Sample 1", "constsize_obs_1_1.xml#24_03_22at13_16_22_group0"))
		aux2 = insFld(aux1, gFld("Within-samples summary", ""))
		insDoc(aux2, gLnk("R", "Basic indices", "constsize_obs_1_1.xml#24_03_22at13_16_22_comp_sum_Basic"))
		insDoc(aux2, gLnk("R", "Heterozygosity", "constsize_obs_1_1.xml#24_03_22at13_16_22_comp_sum_het"))
		insDoc(aux2, gLnk("R", "No. of alleles", "constsize_obs_1_1.xml#24_03_22at13_16_22_comp_sum_numAll"))
		insDoc(aux2, gLnk("R", "Molecular diversity", "constsize_obs_1_1.xml#24_03_22at13_16_22_comp_sum_moldiv"))
		insDoc(aux2, gLnk("R", "Neutrality tests", "constsize_obs_1_1.xml#24_03_22at13_16_22_comp_sum_neutests"))
