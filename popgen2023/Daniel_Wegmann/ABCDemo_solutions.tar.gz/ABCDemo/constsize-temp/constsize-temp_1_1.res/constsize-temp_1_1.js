
USETEXTLINKS = 1
STARTALLOPEN = 0
WRAPTEXT = 1
PRESERVESTATE = 0
HIGHLIGHT = 1
ICONPATH = 'file:////home/wegmann/ABC_test/ABCDemo/'    //change if the gif's folder is a subfolder, for example: 'images/'

foldersTree = gFld("<i>ARLEQUIN RESULTS (constsize-temp_1_1.arp)</i>", "")
insDoc(foldersTree, gLnk("R", "Arlequin log file", "Arlequin_log.txt"))
	aux1 = insFld(foldersTree, gFld("Run of 24/03/22 at 14:07:13", "constsize-temp_1_1.xml#24_03_22at14_07_13"))
	insDoc(aux1, gLnk("R", "Settings", "constsize-temp_1_1.xml#24_03_22at14_07_13_run_information"))
		aux2 = insFld(aux1, gFld("Shared haplotypes", "constsize-temp_1_1.xml#24_03_22at14_07_13_shared%20haplotypes"))
		insDoc(aux2, gLnk("R", "Sample 1", "constsize-temp_1_1.xml#24_03_22at14_07_13_gr_shared0"))
		aux2 = insFld(aux1, gFld("Samples", ""))
		insDoc(aux2, gLnk("R", "Sample 1", "constsize-temp_1_1.xml#24_03_22at14_07_13_group0"))
		aux2 = insFld(aux1, gFld("Within-samples summary", ""))
		insDoc(aux2, gLnk("R", "Basic indices", "constsize-temp_1_1.xml#24_03_22at14_07_13_comp_sum_Basic"))
		insDoc(aux2, gLnk("R", "Heterozygosity", "constsize-temp_1_1.xml#24_03_22at14_07_13_comp_sum_het"))
		insDoc(aux2, gLnk("R", "No. of alleles", "constsize-temp_1_1.xml#24_03_22at14_07_13_comp_sum_numAll"))
		insDoc(aux2, gLnk("R", "Molecular diversity", "constsize-temp_1_1.xml#24_03_22at14_07_13_comp_sum_moldiv"))
		insDoc(aux2, gLnk("R", "Neutrality tests", "constsize-temp_1_1.xml#24_03_22at14_07_13_comp_sum_neutests"))
